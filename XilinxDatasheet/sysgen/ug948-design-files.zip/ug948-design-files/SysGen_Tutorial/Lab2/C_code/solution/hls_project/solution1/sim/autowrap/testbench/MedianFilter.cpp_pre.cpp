# 1 "/proj/dsv_xhd/viswanad/Sysgen_tutorial/Lab2/C_code/solution/MedianFilter.cpp"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 1 "<command-line>" 2
# 1 "/proj/dsv_xhd/viswanad/Sysgen_tutorial/Lab2/C_code/solution/MedianFilter.cpp"
# 1 "/proj/dsv_xhd/viswanad/Sysgen_tutorial/Lab2/C_code/solution/MedianFilter.h" 1



void MedianFilter(unsigned char R, unsigned char G, unsigned char B, unsigned char* V);
# 2 "/proj/dsv_xhd/viswanad/Sysgen_tutorial/Lab2/C_code/solution/MedianFilter.cpp" 2

typedef unsigned char PixelType;




PixelType OptMedian9(PixelType * p)
{
 { if ((p[1])>(p[2])) { PixelType temp=((p[1]));((p[1]))=((p[2]));((p[2]))=temp; }; } ; { if ((p[4])>(p[5])) { PixelType temp=((p[4]));((p[4]))=((p[5]));((p[5]))=temp; }; } ; { if ((p[7])>(p[8])) { PixelType temp=((p[7]));((p[7]))=((p[8]));((p[8]))=temp; }; } ;
 { if ((p[0])>(p[1])) { PixelType temp=((p[0]));((p[0]))=((p[1]));((p[1]))=temp; }; } ; { if ((p[3])>(p[4])) { PixelType temp=((p[3]));((p[3]))=((p[4]));((p[4]))=temp; }; } ; { if ((p[6])>(p[7])) { PixelType temp=((p[6]));((p[6]))=((p[7]));((p[7]))=temp; }; } ;
 { if ((p[1])>(p[2])) { PixelType temp=((p[1]));((p[1]))=((p[2]));((p[2]))=temp; }; } ; { if ((p[4])>(p[5])) { PixelType temp=((p[4]));((p[4]))=((p[5]));((p[5]))=temp; }; } ; { if ((p[7])>(p[8])) { PixelType temp=((p[7]));((p[7]))=((p[8]));((p[8]))=temp; }; } ;
 { if ((p[0])>(p[3])) { PixelType temp=((p[0]));((p[0]))=((p[3]));((p[3]))=temp; }; } ; { if ((p[5])>(p[8])) { PixelType temp=((p[5]));((p[5]))=((p[8]));((p[8]))=temp; }; } ; { if ((p[4])>(p[7])) { PixelType temp=((p[4]));((p[4]))=((p[7]));((p[7]))=temp; }; } ;
 { if ((p[3])>(p[6])) { PixelType temp=((p[3]));((p[3]))=((p[6]));((p[6]))=temp; }; } ; { if ((p[1])>(p[4])) { PixelType temp=((p[1]));((p[1]))=((p[4]));((p[4]))=temp; }; } ; { if ((p[2])>(p[5])) { PixelType temp=((p[2]));((p[2]))=((p[5]));((p[5]))=temp; }; } ;
 { if ((p[4])>(p[7])) { PixelType temp=((p[4]));((p[4]))=((p[7]));((p[7]))=temp; }; } ; { if ((p[4])>(p[2])) { PixelType temp=((p[4]));((p[4]))=((p[2]));((p[2]))=temp; }; } ; { if ((p[6])>(p[4])) { PixelType temp=((p[6]));((p[6]))=((p[4]));((p[4]))=temp; }; } ;
 { if ((p[4])>(p[2])) { PixelType temp=((p[4]));((p[4]))=((p[2]));((p[2]))=temp; }; } ;
    return(p[4]) ;
}

PixelType Mean(PixelType* buffer)
{
    PixelType i, j, min;
    unsigned int sum;
    for (i = 0;i<9; i++) {
     sum+=buffer[i];
    }
    sum/=(3*3);
    return sum;
}

PixelType Min(PixelType* buffer)
{
    PixelType i, j, min;
    min = buffer[0];
    for (i = 1;i<9; i++) {
        if (min>buffer[i]) min = buffer[i];
    }
    return min;
}



void MedianFilter(PixelType row1, PixelType row2, PixelType row3, PixelType* V)
{
#pragma AP PIPELINE II=1



 static PixelType pixelWindowBuffer[3*3];

 PixelType sortBuffer[3*3];




 for(int i = 0;i<3;++i) {
  for(int j=0;j<(3 -1);++j) {
   pixelWindowBuffer[3*i + (3 -j-1)] = pixelWindowBuffer[3*i + (3 -j-1)-1];
  }
 }




    pixelWindowBuffer[0] = row1;
    pixelWindowBuffer[3] = row2;
    pixelWindowBuffer[6] = row3;

    for(int k = 0;k<9;++k) {
     sortBuffer[k] = pixelWindowBuffer[k];
    }

    *V = OptMedian9(sortBuffer);
}
