// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#include <iostream>
#include <cstdlib>
#include  "hls_design.h"
#include  "hls_util.h"
using namespace std;
using namespace HLS_Util;
// [define_apint] ---------->
// [dump_structure [get_structure_list]] ---------->

// [dump_enumeration [get_enumeration_list]] ---------->

// [declare_global_variables] ---------->

// [declare_data_pack_registers] ---------->

// [declare_original_dut] ---------->
extern void MedianFilter (
unsigned char row1,
unsigned char row2,
unsigned char row3,
unsigned char* V);

// [dump_utility_function] ---------->
void HLS_Design::run_c_sim() {

    unsigned char row1;

    unsigned char row2;

    unsigned char row3;

    unsigned char* V = new unsigned char;

    HLS_UINT32 hls_port_index = 0;

    hls_port_index = get_port_index("row1");

    row1 = to_uint64(static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->read_c_value(), static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->get_word_num());

    hls_port_index = get_port_index("row2");

    row2 = to_uint64(static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->read_c_value(), static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->get_word_num());

    hls_port_index = get_port_index("row3");

    row3 = to_uint64(static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->read_c_value(), static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->get_word_num());

MedianFilter(row1, row2, row3, V);

    hls_port_index = get_port_index("V");

    HLS_UINT32 apatb_V_output[static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->get_word_num()];

    to_hls_uint32(apatb_V_output, *((unsigned char *)V), static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->get_word_num());

    static_cast<HLS_Data_Port*>(mPorts[hls_port_index])->write_c_value(apatb_V_output);

    delete V;
}

