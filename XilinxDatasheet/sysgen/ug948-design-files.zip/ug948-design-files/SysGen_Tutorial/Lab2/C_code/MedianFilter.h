
#ifndef __MEDIAN__FILTER__
#define __MEDIAN__FILTER__
void MedianFilter(unsigned char R, unsigned char G, unsigned char B, unsigned char* V);
#endif
